def product(get1, get2):
    result = get1 *get2
    return result

g1 = int(input('getal1?'))
g2 = int(input('getal1?'))

print(product(g1, g2))