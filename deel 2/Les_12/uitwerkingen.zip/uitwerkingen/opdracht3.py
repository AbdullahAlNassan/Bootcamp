woord = input("Voer een woord in: ")

aantal_tekens = len(woord)

print(f"Het woord is: {woord} en bestaat uit {aantal_tekens} tekens.")
