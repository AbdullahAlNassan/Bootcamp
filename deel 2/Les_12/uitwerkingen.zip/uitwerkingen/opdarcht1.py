naam = input("Wat is jouw naam? ")

leeftijd_s = input("Wat is jouw leeftijd? ")

leeftijd = int(leeftijd_s)

leeftijd_over_5_jaar = leeftijd + 5

print(f"{naam}, over 5 jaar zal je {leeftijd_over_5_jaar} jaar oud zijn.")
