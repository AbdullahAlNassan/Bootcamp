woord_1 = input("Wat voor soort dag moet het zijn? ")
stad_1 = input("Noem een stad: ")
naam_1 = input("Geef een naam: ")
woord_3 = input("Kies een willekeurig woord: ")
woord_4 = input("Wat voor man/vrouw zag je? ")
woord_5 = input("Wat verkocht de man/vrouw? ")
woord_6 = input("Noem een willekeurig object: ")
woord_zin_7 = input("Wat deden de mensen in de groep? ")

mad_libs_verhaal = f"Het was een {woord_1} dag in {stad_1}. {naam_1} liep door de straten, op zoek naar een {woord_3}. Plotseling zag {naam_1} een {woord_4} man/vrouw die een {woord_5} verkocht. {naam_1} besloot om het te kopen en liep verder. Toen {naam_1} bij een {woord_6} kwam, zag hij/zij een groep mensen die {woord_zin_7}. {naam_1} besloot om mee te doen en had de tijd van zijn/haar leven."

print(mad_libs_verhaal)
