naam = "Abdullah"

print("Hallo " + naam + ", ik leer nu programmeren.")
