print(15 + 4)  # Uitkomst: 19

print(15 - 4)  # Uitkomst: 11

print(15 * 4)  # Uitkomst: 60

print(15 / 4)  # Uitkomst: 3.75

print(15 // 4)  # Uitkomst: 3

print(15 ** 4)  # Uitkomst: 50.625

print(15 % 4)   # Uitkomst: 3 
