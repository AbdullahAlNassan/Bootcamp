a = 5
b = 10

x = a
a = b
b = x

print(f"a = {a}, b = {b}") 