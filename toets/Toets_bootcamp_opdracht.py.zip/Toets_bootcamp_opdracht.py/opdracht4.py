leeftijd = int(input('Hoe oud ben jij?'))

pensioen = 67 - leeftijd

print(f"Dan duurt het nog ongeveer {pensioen} jaar voordat je met pensioen mag!")