getal1 = 200
getal2 = 5
getal3 = 12

antwoord = getal1 + getal2 + getal3
print(f"De som van {getal1} + {getal2} + {getal3} = {antwoord}")