for getal in range(1, 251):
    print(getal)